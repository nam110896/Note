class VARIABLE():
    DM = None       # Domain
    VR = None       # Variable
    AS = None       # Assign
