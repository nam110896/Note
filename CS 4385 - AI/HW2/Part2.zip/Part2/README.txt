2 python files:
- Variable.py : Include variable class
- mian.py:	Demostrate CSP(funtions: backTrack, forward_checking, sortDomain, selectUnassignValue ) , Display funtions and main runner.

Run command:
fc: 
python main.py ex3.con ex3.var  fc
python main.py ex2.con ex2.var  fc
python main.py ex1.con ex1.var  fc
None:
python main.py ex3.con ex3.var  none
python main.py ex2.con ex2.var  none
python main.py ex1.con ex1.var  none

Make sure you are in  *\example_files>