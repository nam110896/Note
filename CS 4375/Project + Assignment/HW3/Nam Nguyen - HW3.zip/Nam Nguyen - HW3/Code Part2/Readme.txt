To run:
	Open the terminal direct to the folder program
	add command:
	python main.py <file_name> <amount_of_cluster>
	Example: python main.py Health-Tweets/bbchealth.txt 3
	Another way to chech all file in folder Health-Tweets: python main.py ALL <amount_of_cluster> 
	Example: python main.py ALL 3
